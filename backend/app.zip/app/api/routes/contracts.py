from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.schemas.contract import ContractCreate, ContractResponse
from app.crud import contract as crud_contract

router = APIRouter()

@router.post("/", response_model=ContractResponse)
async def create_new_contract(
    contract_in: ContractCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return await crud_contract.create_contract(db, contract_in)

@router.get("/my", response_model=list[ContractResponse])
async def read_my_contracts(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return await crud_contract.get_contracts_for_user(db, current_user.id)