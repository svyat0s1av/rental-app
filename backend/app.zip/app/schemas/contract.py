from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class ContractBase(BaseModel):
    property_id: int
    renter_id: int
    start_date: datetime
    end_date: datetime

class ContractCreate(ContractBase):
    pass

class ContractResponse(ContractBase):
    id: int
    status: str
    document_url: Optional[str] = None

    class Config:
        from_attributes = True