from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.contract import Contract
from app.schemas.contract import ContractCreate

async def create_contract(db: AsyncSession, contract_in: ContractCreate) -> Contract:
    db_contract = Contract(**contract_in.model_dump())
    db.add(db_contract)
    await db.commit()
    await db.refresh(db_contract)
    return db_contract

async def get_contracts_for_user(db: AsyncSession, user_id: int) -> list[Contract]:
    result = await db.execute(select(Contract).where(Contract.renter_id == user_id))
    return list(result.scalars().all())